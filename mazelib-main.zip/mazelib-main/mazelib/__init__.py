__version__ = "0.9.14"

from .mazelib import Maze
